#!/bin/bash
	max_parallel=20
	max_db_size=16

	printf "%4s" "|"
	size_array="1GB 2GB 4GB 8GB 16GB"
	for size in $size_array
	do
		printf "%14s|" $size
	done
	echo ""

	parallel_index=1
	while [ $parallel_index -le $max_parallel ]
	do
		dbsize=1
		parallel=$(printf "%02d" $parallel_index)
		printf "%3s|" $parallel
		while [ $dbsize -le $max_db_size ] 
		do
			dbname=tpch"$dbsize"GB	
			log=$(ls "$parallel"*"$dbname"*.txt)

			parallel_cnt=$(cat $log | grep __parallel__| awk -F '=' '{print $2}')
			load_set=$(cat $log | grep __load__ | awk -F '=' '{print $2}')
			dbname=$(cat $log | grep __database__ | awk -F '=' '{print $2}')
			sql=$(cat $log | grep __sqlname__ | awk -F '=' '{print $2}')
			sql_loop_cnt=$(cat $log | grep __sql_loop_cnt__ | awk -F '=' '{print $2}')
			max_parallel=$(cat $log | grep __max_test_parallel__ | awk -F '=' '{print $2}')

			cpu_idle=$(cat $log | grep Average | awk '{print $12}')
			cpu_load=$( printf "%.2f" $(echo "100 - $cpu_idle" | bc) )

			time=$(cat $log | grep Time | awk '{print $2}')
			avg_time=$(echo "$time" | awk '{sum+=$1} END {print sum/NR}')

			printf "%8s" $(printf "%7.2f" $avg_time)
			printf "%7s" $(printf "(%2.2f)|" $cpu_load)

			dbsize=$(( $dbsize*2 ))
		done
		echo ""
		parallel_index=$(( $parallel_index+ 1))
	done

