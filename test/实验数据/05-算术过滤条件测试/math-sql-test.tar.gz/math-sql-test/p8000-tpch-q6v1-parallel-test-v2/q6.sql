\timing on
select
  sum(l_extendedprice * l_discount) as revenue
from
  lineitem
where
        l_quantity*l_extendedprice*(1-l_discount) < 64000 and
        l_shipdate >= date '1994-01-01' and
        l_shipdate < date '1994-01-01' + interval '1' year;

