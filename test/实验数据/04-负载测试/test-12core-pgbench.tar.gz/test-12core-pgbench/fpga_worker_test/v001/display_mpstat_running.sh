#!/bin/bash

parallel_cnt_max=8
cpu_load_max=80

cpu_load=0
parallel_cnt=0

printf "%2s|"
while [ $cpu_load  -le $cpu_load_max ] 
do
	printf "%9s|" "$cpu_load"
	cpu_load=$(( $cpu_load + 10 ))
done
printf "%s\n"

while [ $parallel_cnt -le $parallel_cnt_max ] 
do
	cpu_load=0
	printf "%2s|" "$parallel_cnt"
	while [ $cpu_load  -le $cpu_load_max ] 
	do
		c_load=$(printf "%02d" $cpu_load)
		p_cnt=$(printf "%02d" $parallel_cnt)
		filepath=mpstat/$c_load-$p_cnt-mpstat_running.txt	
		cpu_idle_val=$(cat $filepath | grep Average | grep -v "CPU" | awk '{print $12}')
		cpu_load_val=$( printf "%.2f" $(echo "100 - $cpu_idle_val" | bc) )
		printf "%10s" "$cpu_load_val|"
		cpu_load=$(( $cpu_load + 10 ))
	done

	printf "%s\n"
	parallel_cnt=$(( $parallel_cnt + 1))
done

