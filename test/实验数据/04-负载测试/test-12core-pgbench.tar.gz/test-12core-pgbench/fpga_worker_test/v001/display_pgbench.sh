#!/bin/bash

parallel_cnt_max=8
cpu_load_max=80

cpu_load=0
parallel_cnt=0

printf "%2s|"
while [ $cpu_load  -le $cpu_load_max ] 
do
	printf "%9s|" "$cpu_load"
	cpu_load=$(( $cpu_load + 10 ))
done
printf "%s\n"

while [ $parallel_cnt -le $parallel_cnt_max ] 
do
	cpu_load=0
	printf "%2s|" "$parallel_cnt"
	while [ $cpu_load  -le $cpu_load_max ] 
	do
		c_load=$(printf "%02d" $cpu_load)
		p_cnt=$(printf "%02d" $parallel_cnt)
		filepath=pgbench/$c_load-$p_cnt-cpu-parallel-pgbench.txt	
		query_time_avg=$(cat $filepath | grep average | awk '{print $4}')
		printf "%10s" "$query_time_avg |"
		cpu_load=$(( $cpu_load + 10 ))
	done

	printf "%s\n"
	parallel_cnt=$(( $parallel_cnt + 1))
done

