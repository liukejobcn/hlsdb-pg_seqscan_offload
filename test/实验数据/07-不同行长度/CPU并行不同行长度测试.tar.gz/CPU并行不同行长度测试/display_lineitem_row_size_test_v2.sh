#!/bin/bash
	parallel_index=0

	rowsize_array="100 200 300 400 500 600"
	echo -n "   "
	for rowsize in $rowsize_array
	do
		printf "%7d|" $rowsize
	done
	echo ""

	while [ $parallel_index -le 12 ]
	do
		parallel=$(printf "%02d" $parallel_index)
		logs=$(ls "$parallel"_*)

		printf "%02d|" "$parallel_index"
		for log in $logs
		do
			parallel_cnt=$(cat $log | grep __parallel__| awk -F '=' '{print $2}')
			load_set=$(cat $log | grep __load__ | awk -F '=' '{print $2}')
			dbname=$(cat $log | grep __database__ | awk -F '=' '{print $2}')
			sql=$(cat $log | grep __sqlname__ | awk -F '=' '{print $2}')
			sql_loop_cnt=$(cat $log | grep __sql_loop_cnt__ | awk -F '=' '{print $2}')
			max_parallel=$(cat $log | grep __max_test_parallel__ | awk -F '=' '{print $2}')

			cpu_idle=$(cat $log | grep Average | awk '{print $12}')
			cpu_load=$( printf "%.2f" $(echo "100 - $cpu_idle" | bc) )


			time=$(cat $log | grep Time | awk '{print $2}')
			avg_time=$(echo "$time" | awk '{sum+=$1} END {print sum/NR}')

			printf "%8s" $(printf "%4.2f|" $avg_time)
		done
		echo ""

		parallel_index=$(( $parallel_index+ 1))
	done
