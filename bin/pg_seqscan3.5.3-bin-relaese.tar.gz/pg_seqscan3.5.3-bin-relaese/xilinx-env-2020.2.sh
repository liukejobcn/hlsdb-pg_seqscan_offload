source /opt/Xilinx-2020.2/Vitis/2020.2/settings64.sh
source /opt/xilinx/xrt/setup.sh
export LIBRARY_PATH=/usr/lib/x86_64-linux-gnu

